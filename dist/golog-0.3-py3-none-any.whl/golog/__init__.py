# import submodules you want to install

from .logging import *
from .tools import *


__docformat__ = "restructuredtext"


# module level doc-string
__doc__ = """
golog - a powerful general logging library for Python
=====================================================================

*golog* is a Python package providing many different useful functions

Main Features
-------------
Here are just a few of the things that iago does well:

  - TODO
"""
